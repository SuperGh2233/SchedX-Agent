"""Independent-process cgroup admission, changing load, and crash recovery."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time
import uuid

SOURCE = Path('/var/tmp/schedx-admission-20261006-f265822/candidate-068c7ba')
sys.path.insert(0, str(SOURCE))
from schedx.admission import AdmissionConfig, ToolAdmission
from schedx.benchmark.versioning import source_digest
from schedx.controllers.scx_controller import ScxController
from schedx.state import atomic_json
from schedx.tool_runner import ToolCallRunner


def config(raw):
    return AdmissionConfig(**json.loads(raw))


def worker(args):
    ctl = ToolAdmission(args.namespace, config(args.config), cgroup_root=args.root)
    runner = ToolCallRunner(root=args.root, state_dir=args.output, native_scx=False, admission=ctl)
    code = f"""import os,time,subprocess
from pathlib import Path
os.sched_setaffinity(0, {args.cpus!r})
"""
    if args.marker:
        code += f"Path({str(args.marker)!r}).touch()\n"
    if args.descendant:
        code += "subprocess.Popen(['sleep','60'])\n"
    if args.sleep:
        code += f"time.sleep({args.sleep!r})\n"
    else:
        code += f"end=time.process_time()+{args.cpu_seconds!r}\nwhile time.process_time()<end:\n sum(range(1000))\n"
    result = runner.run([sys.executable, '-c', code], agent_id=args.agent, intent=args.intent,
                        profile_overrides={'cpu_max': 'max'}, timeout=args.timeout, output_limit=1024)
    print(json.dumps(result), flush=True)
    return 0


def command(args, root, namespace, configuration, output, agent, intent, cpu_seconds=.1, timeout=30, marker=None, sleep=0, descendant=False):
    result = [sys.executable, str(Path(__file__).resolve()), '--worker', '--root', str(root),
              '--namespace', str(namespace), '--config', json.dumps(asdict(configuration)), '--output', str(output),
              '--agent', agent, '--intent', intent, '--cpu-seconds', str(cpu_seconds), '--timeout', str(timeout),
              '--cpus', *[str(cpu) for cpu in args.cpus]]
    if marker:
        result += ['--marker', str(marker)]
    if sleep:
        result += ['--sleep', str(sleep)]
    if descendant:
        result += ['--descendant']
    return result


def invoke(argv, output):
    process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
    try:
        stdout, stderr = process.communicate(timeout=45)
    except BaseException:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait()
        raise
    (output / 'worker.stdout').write_text(stdout)
    (output / 'worker.stderr').write_text(stderr)
    if process.returncode:
        raise RuntimeError(f'worker exited {process.returncode}: {stderr[-1000:]}')
    return json.loads(stdout)


def check_result(result):
    assert result['returncode'] == 0 and result['command_started'], result
    assert result['process_wait_mode'] == 'pidfd'
    assert result['cleanup']['cgroup_removed'] and result['cleanup']['admission_released']
    assert result['cleanup']['policy_removed'] and result['cleanup']['scheduler_stopped']
    assert result['cpu_control_support_at_launch']['cpu_max'] == 'cgroup_v2'


def recovery(args, root, output):
    output.mkdir()
    namespace = Path('/run/schedx') / ('admission-recovery-' + uuid.uuid4().hex)
    configuration = AdmissionConfig(mode='fixed', initial_limit=1, max_limit=1, interactive_reserve=0)
    ctl = ToolAdmission(namespace, configuration, cgroup_root=root)
    now = time.monotonic()
    holder = ctl.acquire('holder', 'interactive', submitted_at=now, deadline=now + 30)
    marker = output / 'queued-command-executed'
    try:
        location = output / 'queued'
        location.mkdir()
        queued = invoke(command(args, root, namespace, configuration, location, 'queued', 'interactive',
                                timeout=.1, marker=marker), location)
        assert queued['returncode'] == 124 and queued['timeout_phase'] == 'queue'
        assert not queued['command_started'] and not marker.exists()
    finally:
        ctl.release(holder)
    location = output / 'timeout'
    location.mkdir()
    timed = invoke(command(args, root, namespace, configuration, location, 'timeout', 'interactive',
                           timeout=.3, sleep=60, descendant=True), location)
    assert timed['returncode'] == 124 and timed['timeout_phase'] == 'execution'
    assert timed['cleanup']['cgroup_removed'] and timed['cleanup']['admission_released']
    marker = output / 'crash-command-executed'
    location = output / 'crash'
    location.mkdir()
    process = subprocess.Popen(command(args, root, namespace, configuration, location, 'crash', 'interactive',
                                       marker=marker, sleep=60, descendant=True),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
    try:
        deadline = time.monotonic() + 10
        while not marker.exists() and time.monotonic() < deadline:
            time.sleep(.02)
        assert marker.exists(), 'crash test never reached the tool command'
        snapshot = ctl.snapshot()
        live = next(row for row in snapshot['jobs'].values() if row['agent'] == 'crash')
        group = Path(live['cgroup'])
        assert root / 'schedx-agents' in group.parents
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)
        assert ctl.snapshot()['active'] == 1, 'live child released its capacity when the caller died'
        location2 = output / 'orphan-wait'
        location2.mkdir()
        waiting = invoke(command(args, root, namespace, configuration, location2, 'orphan-wait', 'interactive',
                                 timeout=.1, marker=output / 'orphan-wait-executed'), location2)
        assert waiting['timeout_phase'] == 'queue' and not waiting['command_started']
        (group / 'cgroup.kill').write_text('1')
        deadline = time.monotonic() + 5
        while ctl.snapshot()['active'] and time.monotonic() < deadline:
            time.sleep(.02)
        assert not ctl.snapshot()['active']
        for path in (group, group.parent, group.parent.parent):
            if path.exists():
                path.rmdir()
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        process.stdout.close()
        process.stderr.close()
    snapshot = ctl.snapshot()
    assert snapshot['active'] == snapshot['pending'] == 0
    summary = {'status': 'passed', 'queue_timeout_before_execution': True, 'timeout_tree_cleanup': True,
               'crash_keeps_live_descendants_in_capacity': True, 'orphan_recovery_after_owned_cgroup_kill': True,
               'final_admission': snapshot}
    atomic_json(output / 'summary.json', summary)
    import shutil
    shutil.copytree(namespace, output / 'admission-final')
    shutil.rmtree(namespace)
    return summary


def parent(args):
    assert sys.platform == 'linux' and os.geteuid() == 0
    assert ScxController().state() == 'disabled'
    assert all((Path('/proc/pressure') / name).exists() for name in ('cpu', 'memory', 'io'))
    args.output.mkdir(parents=True, exist_ok=False)
    allowed = os.sched_getaffinity(0)
    args.cpus = sorted(allowed - {max(allowed)})
    assert args.cpus
    root = Path('/sys/fs/cgroup') / ('schedx-admission-soak-' + uuid.uuid4().hex)
    root.mkdir()
    namespace = Path('/run/schedx') / ('admission-soak-' + uuid.uuid4().hex)
    configuration = AdmissionConfig(initial_limit=5, max_limit=8, interactive_reserve=2)
    ctl = ToolAdmission(namespace, configuration, cgroup_root=root)
    started = time.monotonic()
    report = {'status': 'running', 'duration_seconds': args.duration,
              'production_source_sha256': source_digest(SOURCE),
              'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'configuration': asdict(configuration), 'kernel': os.uname().release, 'waves': 0, 'tools': 0,
              'recovery_checks': 0, 'max_pending': 0, 'max_active': 0, 'max_queue_seconds': {},
              'max_total_seconds': {}, 'failures': [], 'native_backend': False}
    stop = threading.Event()
    monitor_errors = []
    def monitor():
        try:
            with (args.output / 'control.jsonl').open('w') as log:
                while not stop.wait(.2):
                    value = ctl.snapshot()
                    assert value['active'] <= configuration.max_limit
                    assert value['pending'] <= configuration.max_pending
                    report['max_active'] = max(report['max_active'], value['active'])
                    report['max_pending'] = max(report['max_pending'], value['pending'])
                    value.pop('jobs')
                    log.write(json.dumps({'elapsed': time.monotonic() - started, **value}) + '\n')
                    log.flush()
        except BaseException as exc:
            monitor_errors.append(repr(exc))
    thread = threading.Thread(target=monitor)
    thread.start()
    last_recovery = -120.0
    try:
        while time.monotonic() - started < args.duration:
            elapsed = time.monotonic() - started
            if elapsed - last_recovery >= 120:
                recovery(args, root, args.output / ('recovery-' + str(report['recovery_checks'])))
                report['recovery_checks'] += 1
                last_recovery = elapsed
            intense = int(elapsed // 30) % 2 == 1
            count = 12 if intense else 4
            wave = args.output / ('wave-' + str(report['waves']))
            wave.mkdir()
            def job(index):
                intent = 'interactive' if index % 4 == 3 else 'compile'
                location = wave / str(index)
                location.mkdir()
                argv = command(args, root, namespace, configuration, location, 'agent-' + str(index % 3),
                               intent, cpu_seconds=.02 if intent == 'interactive' else .8 if intense else .15)
                row = invoke(argv, location)
                check_result(row)
                atomic_json(location / 'result.json', row)
                return row
            with ThreadPoolExecutor(max_workers=count) as pool:
                results = list(pool.map(job, range(count)))
            assert ctl.snapshot()['active'] == ctl.snapshot()['pending'] == 0
            for row in results:
                intent = row['intent']
                report['max_queue_seconds'][intent] = max(report['max_queue_seconds'].get(intent, 0), row['queue_wait_seconds'])
                report['max_total_seconds'][intent] = max(report['max_total_seconds'].get(intent, 0), row['duration_seconds'])
                assert row['duration_seconds'] <= 30.5, 'submission budget exceeded beyond cleanup allowance'
            report['waves'] += 1
            report['tools'] += count
            if monitor_errors:
                raise RuntimeError(';'.join(monitor_errors))
            state = json.loads(ctl.path.read_text())
            assert len(state['completions']) <= 64 and not state['last_served']
            atomic_json(args.output / 'summary.json', report)
            time.sleep(.05)
        report['status'] = 'passed'
    except BaseException as exc:
        report.update(status='failed', error=repr(exc))
    finally:
        stop.set()
        thread.join(timeout=6)
        if thread.is_alive() or monitor_errors:
            report.update(status='failed', monitor_errors=monitor_errors, monitor_stopped=not thread.is_alive())
        if (root / 'cgroup.kill').exists():
            (root / 'cgroup.kill').write_text('1')
        for path in sorted((p for p in root.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
            try:
                path.rmdir()
            except OSError as exc:
                report['failures'].append('private_group_cleanup:' + str(exc))
        try:
            root.rmdir()
            report['private_cgroup_removed'] = True
        except OSError as exc:
            report.update(status='failed', cleanup_error=str(exc), private_cgroup_removed=False)
        report['elapsed_seconds'] = time.monotonic() - started
        report['final_scheduler_state'] = ScxController().state()
        if report['final_scheduler_state'] != 'disabled' or report['failures']:
            report['status'] = 'failed'
        import shutil
        if namespace.exists():
            shutil.copytree(namespace, args.output / 'admission-final', dirs_exist_ok=True)
            shutil.rmtree(namespace)
        atomic_json(args.output / 'summary.json', report)
    print(json.dumps(report), flush=True)
    return 0 if report['status'] == 'passed' else 1


parser = argparse.ArgumentParser()
parser.add_argument('--worker', action='store_true')
parser.add_argument('--root', type=Path)
parser.add_argument('--namespace', type=Path)
parser.add_argument('--config')
parser.add_argument('--agent')
parser.add_argument('--intent', default='interactive')
parser.add_argument('--cpu-seconds', type=float, default=.1)
parser.add_argument('--sleep', type=float, default=0)
parser.add_argument('--marker', type=Path)
parser.add_argument('--descendant', action='store_true')
parser.add_argument('--timeout', type=float, default=30)
parser.add_argument('--cpus', type=int, nargs='+')
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--duration', type=float, default=180)
if __name__ == '__main__':
    args = parser.parse_args()
    raise SystemExit(worker(args) if args.worker else parent(args))
