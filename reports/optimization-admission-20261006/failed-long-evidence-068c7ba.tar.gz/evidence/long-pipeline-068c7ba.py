import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/var/tmp/schedx-admission-20261006-f265822')
SOURCE = ROOT / 'candidate-068c7ba'
EVIDENCE = ROOT / 'evidence'
OUTPUT = EVIDENCE / 'final-validation-068c7ba'
OUTPUT.mkdir(exist_ok=False)
sys.path.insert(0, str(SOURCE))
from schedx.benchmark.versioning import source_digest
from schedx.state import atomic_json


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def load(path):
    return json.loads(path.read_text())


status = {'status': 'running', 'pid': os.getpid(), 'commit': '068c7ba9c0c523e381fcf343618ef8d7d30efa06',
          'source_sha256': source_digest(SOURCE), 'guest_started_utc': now(), 'stages': [],
          'harness_sha256': hashlib.sha256((EVIDENCE / 'admission-soak-068c7ba.py').read_bytes()).hexdigest(),
          'windows_shutdown_requested': False, 'boot_configuration_restored': True}
started = time.monotonic()
def save():
    atomic_json(OUTPUT / 'pipeline.json', status)
save()
try:
    assert status['source_sha256'] == 'be3a39455ebaa31d43b29955240178cc4455c15f966ce40d27b63fded7c6a24c'
    for name in ('paired-3', 'soak-smoke-1', 'cpu-contract-pidfd', 'native-pidfd-compatibility'):
        summary = load(EVIDENCE / name / 'summary.json')
        assert summary['status'] == 'passed', name
    status['prerequisites'] = {'paired_comparison': 'passed', 'smoke': 'passed', 'hard_cpu_contract': 'passed', 'native_compatibility': 'passed'}
    save()
    for name, duration in (('admission-30min', 1800), ('admission-2h', 7200)):
        assert Path('/sys/kernel/sched_ext/state').read_text().strip() == 'disabled'
        row = {'name': name, 'status': 'running', 'duration_seconds': duration, 'guest_started_utc': now()}
        status['stages'].append(row)
        save()
        with (OUTPUT / (name + '.log')).open('w') as log:
            process = subprocess.Popen([sys.executable, str(EVIDENCE / 'admission-soak-068c7ba.py'),
                '--output', str(OUTPUT / name), '--duration', str(duration)], cwd=SOURCE,
                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
            row['pid'] = process.pid
            save()
            code = process.wait()
        summary = load(OUTPUT / name / 'summary.json')
        passed = code == 0 and summary['status'] == 'passed' and summary.get('private_cgroup_removed')
        row.update(status='passed' if passed else 'failed', returncode=code, tools=summary.get('tools'),
            recovery_checks=summary.get('recovery_checks'), max_queue_seconds=summary.get('max_queue_seconds'),
            max_total_seconds=summary.get('max_total_seconds'), guest_finished_utc=now())
        save()
        if not passed:
            raise RuntimeError(name + ' failed; later experiments not started')
    assert source_digest(SOURCE) == status['source_sha256']
    before = load(EVIDENCE / 'original-files-before.json')
    mismatches = []
    for name, expected in before.items():
        path = Path('/root/SchedX-Agent') / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            mismatches.append(name)
    status['original_workspace_audit'] = {'regular_files_checked': len(before), 'mismatches': mismatches}
    assert not mismatches, 'original workspace contents changed'
    assert hashlib.sha256(Path('/usr/local/bin/scx_agent').read_bytes()).hexdigest() == '6e2148d333d5833dc889f8436b7746661edd61d9c78e89b57b4a54bd8f373f39'
    assert Path('/sys/kernel/sched_ext/state').read_text().strip() == 'disabled'
    assert not list(Path('/sys/fs/bpf').iterdir())
    assert not Path('/run/schedx/scx-daemon.sock').exists()
    status['status'] = 'passed'
except BaseException as exc:
    status.update(status='failed', error=repr(exc))
finally:
    setup = load(EVIDENCE / 'cpu-controller-test-setup.json')
    try:
        remaining = [str(path) for path in Path('/sys/fs/cgroup').rglob('*') if path.is_dir()
                     and path.name.startswith(('schedx-admission-', 'schedx-net-verify-', 'schedx-verify-'))]
        status['remaining_private_cgroups'] = remaining
        assert not remaining, 'private groups remain; preserve their evidence before restoring controls'
        subtree = Path('/sys/fs/cgroup/cgroup.subtree_control')
        if setup['added_cpu']:
            subtree.write_text('-cpu')
        assert set(subtree.read_text().split()) == set(setup['before'])
        setup.update(restored=True, restored_guest_utc=now())
        atomic_json(EVIDENCE / 'cpu-controller-test-setup.json', setup)
        status['cpu_controller_restored'] = True
    except BaseException as exc:
        status.update(status='failed', cleanup_error=repr(exc), cpu_controller_restored=False)
    status.update(guest_finished_utc=now(), elapsed_seconds=time.monotonic() - started,
                  final_scheduler_state=Path('/sys/kernel/sched_ext/state').read_text().strip())
    save()
    # Preserve a terminal bundle independently of the SSH session.
    archive = ROOT / 'final-evidence-068c7ba.tar.gz'
    result = subprocess.run(['tar', '-czf', str(archive), '--exclude=evidence/boot-config-before', '-C', str(ROOT), 'evidence'], capture_output=True, text=True)
    status['terminal_archive'] = {'path': str(archive), 'returncode': result.returncode,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest() if result.returncode == 0 else None,
        'scope': 'all experiment evidence; private boot backup retained separately'}
    save()
    print(json.dumps(status), flush=True)
raise SystemExit(0 if status['status'] == 'passed' else 1)
