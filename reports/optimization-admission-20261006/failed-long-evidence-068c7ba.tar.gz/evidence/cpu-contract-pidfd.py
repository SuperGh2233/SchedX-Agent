import json
from pathlib import Path
import sys
import uuid
ROOT = Path('/var/tmp/schedx-admission-20261006-f265822')
sys.path.insert(0, str(ROOT / 'candidate-068c7ba'))
from schedx.controllers.scx_controller import ScxController
from schedx.state import atomic_json
from schedx.tool_runner import ToolCallRunner
output = ROOT / 'evidence/cpu-contract-pidfd'
output.mkdir()
assert ScxController().state() == 'disabled'
runner = ToolCallRunner(state_dir=output, native_scx=False)
code = 'import time\nend=time.monotonic()+2\nwhile time.monotonic()<end:\n sum(range(1000))\n'
result = runner.run([sys.executable, '-c', code], agent_id='pidfd-contract-' + uuid.uuid4().hex[:8],
                    intent='interactive', profile_overrides={'cpu_max': '10000 100000'}, timeout=8)
cpu_seconds = result['metrics']['cpu_stat']['usage_usec'] / 1e6
assert result['returncode'] == 0 and .1 <= cpu_seconds <= .4
assert result['process_wait_mode'] == 'pidfd' and result['cpu_control_support_at_launch']['cpu_max'] == 'cgroup_v2'
assert result['cleanup']['cgroup_removed'] and result['cleanup']['policy_removed']
assert ScxController().state() == 'disabled'
atomic_json(output / 'summary.json', {'status': 'passed', 'quota_cpu_seconds': cpu_seconds, 'quota': '10000 100000',
    'wall_work_seconds': 2, 'pidfd_wait_used': True, 'cleanup': result['cleanup'], 'final_scheduler_state': 'disabled'})
print(json.dumps({'status': 'passed', 'quota_cpu_seconds': cpu_seconds}))
