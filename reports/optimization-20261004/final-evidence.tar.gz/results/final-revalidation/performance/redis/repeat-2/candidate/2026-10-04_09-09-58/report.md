# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83236.23 | n/a | 1.24 | n/a | n/a | True |
| interference | 58506.91 | n/a | 4.09 | n/a | 100.00% | True |
| schedx | 95038.96 | n/a | 1.56 | n/a | 44.61% | True |

## Result

- Interference QPS drop: 29.71%
- Agent QPS recovery: 62.44%
- Agent P99 reduction: 61.85%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.