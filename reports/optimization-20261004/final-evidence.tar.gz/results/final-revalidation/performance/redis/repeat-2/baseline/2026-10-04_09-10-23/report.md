# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 86865.88 | n/a | 1.22 | n/a | n/a | True |
| interference | 71123.75 | n/a | 3.47 | n/a | 100.00% | True |
| schedx | 95020.91 | n/a | 2.24 | n/a | 59.36% | True |

## Result

- Interference QPS drop: 18.12%
- Agent QPS recovery: 33.60%
- Agent P99 reduction: 35.49%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.