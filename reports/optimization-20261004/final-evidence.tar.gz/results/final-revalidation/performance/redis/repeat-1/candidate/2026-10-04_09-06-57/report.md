# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83250.09 | n/a | 1.26 | n/a | n/a | True |
| interference | 79693.98 | n/a | 3.28 | n/a | 100.00% | True |
| schedx | 95020.91 | n/a | 1.57 | n/a | 69.80% | True |

## Result

- Interference QPS drop: 4.27%
- Agent QPS recovery: 19.23%
- Agent P99 reduction: 52.21%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.