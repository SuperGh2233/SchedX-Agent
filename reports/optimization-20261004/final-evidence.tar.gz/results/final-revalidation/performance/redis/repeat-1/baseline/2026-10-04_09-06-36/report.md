# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83236.23 | n/a | 1.24 | n/a | n/a | True |
| interference | 83028.90 | n/a | 3.33 | n/a | 100.00% | True |
| schedx | 95038.96 | n/a | 2.34 | n/a | 73.30% | False |

## Result

- Interference QPS drop: 0.25%
- Agent QPS recovery: 14.46%
- Agent P99 reduction: 29.58%
- Fairness floor: 25.00%
- Result valid for claims: False

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.