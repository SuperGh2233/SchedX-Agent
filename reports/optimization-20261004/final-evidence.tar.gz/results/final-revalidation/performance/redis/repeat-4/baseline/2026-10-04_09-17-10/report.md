# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83250.09 | n/a | 1.25 | n/a | n/a | True |
| interference | 73713.70 | n/a | 3.49 | n/a | 100.00% | True |
| schedx | 95020.91 | n/a | 2.27 | n/a | 61.12% | True |

## Result

- Interference QPS drop: 11.46%
- Agent QPS recovery: 28.91%
- Agent P99 reduction: 34.87%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.