# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83263.95 | n/a | 1.23 | n/a | n/a | True |
| interference | 76569.68 | n/a | 3.29 | n/a | 100.00% | True |
| schedx | 95038.96 | n/a | 1.59 | n/a | 67.03% | True |

## Result

- Interference QPS drop: 8.04%
- Agent QPS recovery: 24.12%
- Agent P99 reduction: 51.71%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.