# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83222.38 | n/a | 1.24 | n/a | n/a | True |
| interference | 82836.32 | n/a | 3.37 | n/a | 100.00% | True |
| schedx | 95057.03 | n/a | 2.34 | n/a | 74.56% | False |

## Result

- Interference QPS drop: 0.46%
- Agent QPS recovery: 14.75%
- Agent P99 reduction: 30.41%
- Fairness floor: 25.00%
- Result valid for claims: False

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.