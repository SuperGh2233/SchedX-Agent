# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83236.23 | n/a | 1.25 | n/a | n/a | True |
| interference | 79478.62 | n/a | 3.46 | n/a | 100.00% | True |
| schedx | 95075.11 | n/a | 1.58 | n/a | 70.51% | True |

## Result

- Interference QPS drop: 4.51%
- Agent QPS recovery: 19.62%
- Agent P99 reduction: 54.18%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.