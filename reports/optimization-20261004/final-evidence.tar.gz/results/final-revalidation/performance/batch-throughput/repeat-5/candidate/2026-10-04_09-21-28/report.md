# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19545.47 | 0.32 | 99.01% | 0.00% |
| interference | 9821.29 | 2.97 | 0.00% | 100.00% |
| schedx | 15941.54 | 0.32 | 62.32% | 33.35% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True