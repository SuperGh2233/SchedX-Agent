# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19515.51 | 0.32 | 97.23% | 0.00% |
| interference | 9894.62 | 2.97 | 0.00% | 100.00% |
| schedx | 16271.03 | 0.32 | 64.44% | 30.19% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True