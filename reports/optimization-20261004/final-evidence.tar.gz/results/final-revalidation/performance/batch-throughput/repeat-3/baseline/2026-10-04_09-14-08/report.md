# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19501.24 | 0.32 | 97.71% | 0.00% |
| interference | 9863.70 | 3.02 | 0.00% | 100.00% |
| schedx | 16354.17 | 0.32 | 65.80% | 29.78% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True