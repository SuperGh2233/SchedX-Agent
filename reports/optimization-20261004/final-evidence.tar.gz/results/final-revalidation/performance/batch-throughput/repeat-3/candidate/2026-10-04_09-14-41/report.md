# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19632.11 | 0.32 | 98.21% | 0.00% |
| interference | 9904.52 | 2.91 | 0.00% | 100.00% |
| schedx | 16070.63 | 0.32 | 62.26% | 32.70% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True