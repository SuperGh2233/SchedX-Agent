# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19722.92 | 0.31 | 99.23% | 0.00% |
| interference | 9899.50 | 2.97 | 0.00% | 100.00% |
| schedx | 15951.89 | 0.32 | 61.14% | 33.74% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True