# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19698.10 | 0.31 | 99.11% | 0.00% |
| interference | 9893.07 | 2.97 | 0.00% | 100.00% |
| schedx | 16217.82 | 0.32 | 63.93% | 30.25% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True