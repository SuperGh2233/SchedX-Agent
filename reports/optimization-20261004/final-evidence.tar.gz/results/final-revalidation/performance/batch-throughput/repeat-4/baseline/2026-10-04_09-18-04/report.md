# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19638.93 | 0.32 | 100.96% | 0.00% |
| interference | 9772.77 | 2.97 | 0.00% | 100.00% |
| schedx | 16354.97 | 0.32 | 67.35% | 30.00% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True