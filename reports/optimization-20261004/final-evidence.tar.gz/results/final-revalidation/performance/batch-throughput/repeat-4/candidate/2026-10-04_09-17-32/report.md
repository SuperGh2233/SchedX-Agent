# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19512.81 | 0.32 | 96.99% | 0.00% |
| interference | 9905.58 | 2.97 | 0.00% | 100.00% |
| schedx | 15986.79 | 0.32 | 61.39% | 33.40% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True