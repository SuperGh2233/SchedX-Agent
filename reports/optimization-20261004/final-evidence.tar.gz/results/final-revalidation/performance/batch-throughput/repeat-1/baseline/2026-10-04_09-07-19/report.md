# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19656.15 | 0.31 | 98.15% | 0.00% |
| interference | 9919.97 | 2.97 | 0.00% | 100.00% |
| schedx | 16376.26 | 0.32 | 65.08% | 29.59% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True