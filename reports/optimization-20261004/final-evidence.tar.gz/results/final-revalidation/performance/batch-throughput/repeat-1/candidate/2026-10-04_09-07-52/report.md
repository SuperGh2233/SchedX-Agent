# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19568.28 | 0.32 | 98.00% | 0.00% |
| interference | 9882.88 | 2.97 | 0.00% | 100.00% |
| schedx | 15775.42 | 0.32 | 59.62% | 35.20% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True