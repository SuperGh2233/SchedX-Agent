# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 66540.75 | 5.67 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 99406.77 | 5.63 | 49.39% | 0.71% | 49.65% | True |
| scx_only | 116152.63 | 2.12 | 74.56% | 62.61% | 29.37% | True |
| agent_combined | 113445.33 | 2.35 | 70.49% | 58.55% | 28.83% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.