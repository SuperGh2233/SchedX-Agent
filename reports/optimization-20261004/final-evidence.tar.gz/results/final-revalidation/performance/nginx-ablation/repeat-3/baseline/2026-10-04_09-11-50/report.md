# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 58949.38 | 7.34 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 98943.50 | 5.14 | 67.84% | 29.97% | 45.09% | True |
| scx_only | 115373.89 | 4.25 | 95.72% | 42.10% | 27.97% | True |
| agent_combined | 113333.45 | 4.56 | 92.26% | 37.87% | 26.44% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.