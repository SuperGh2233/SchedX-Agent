# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 56093.62 | 6.38 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 99391.55 | 4.83 | 77.19% | 24.29% | 44.24% | True |
| scx_only | 116029.15 | 2.01 | 106.85% | 68.50% | 26.95% | True |
| agent_combined | 112908.12 | 2.29 | 101.29% | 64.11% | 25.45% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.