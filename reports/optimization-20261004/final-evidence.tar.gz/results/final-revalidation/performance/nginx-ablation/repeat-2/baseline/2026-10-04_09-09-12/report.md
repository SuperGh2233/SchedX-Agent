# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 68254.38 | 6.24 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 99400.79 | 4.97 | 45.63% | 20.35% | 50.91% | True |
| scx_only | 115471.01 | 4.30 | 69.18% | 31.09% | 31.30% | True |
| agent_combined | 112826.73 | 4.43 | 65.30% | 29.01% | 30.59% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.