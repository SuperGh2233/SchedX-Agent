# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 75443.74 | 5.79 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 106122.92 | 4.69 | 40.66% | 19.00% | 53.02% | True |
| scx_only | 123004.19 | 2.72 | 63.04% | 53.02% | 33.00% | True |
| agent_combined | 119468.69 | 2.67 | 58.35% | 53.89% | 32.68% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.