# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 68783.47 | 5.89 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 100176.73 | 5.61 | 45.64% | 4.75% | 51.35% | True |
| scx_only | 122808.60 | 5.59 | 78.54% | 5.09% | 32.47% | True |
| agent_combined | 118492.83 | 5.26 | 72.27% | 10.70% | 32.06% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.