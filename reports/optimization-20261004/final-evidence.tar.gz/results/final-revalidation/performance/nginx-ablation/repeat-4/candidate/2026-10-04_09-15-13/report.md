# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 65392.25 | 5.92 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 98775.36 | 5.32 | 51.05% | 10.14% | 48.96% | True |
| scx_only | 115962.95 | 2.07 | 77.33% | 65.03% | 29.19% | True |
| agent_combined | 113531.15 | 2.25 | 73.62% | 61.99% | 28.51% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.