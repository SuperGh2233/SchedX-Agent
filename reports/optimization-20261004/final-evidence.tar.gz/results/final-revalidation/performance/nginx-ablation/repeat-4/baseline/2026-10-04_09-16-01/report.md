# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 70017.52 | 7.42 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 98516.20 | 4.88 | 40.70% | 34.23% | 52.46% | True |
| scx_only | 115739.16 | 4.14 | 65.30% | 44.20% | 31.97% | True |
| agent_combined | 112949.80 | 4.67 | 61.32% | 37.06% | 30.77% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.