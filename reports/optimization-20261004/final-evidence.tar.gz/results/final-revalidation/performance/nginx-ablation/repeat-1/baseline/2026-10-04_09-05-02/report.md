# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 68225.98 | 6.04 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 100901.15 | 5.71 | 47.89% | 5.46% | 50.61% | True |
| scx_only | 116369.01 | 4.50 | 70.56% | 25.50% | 31.36% | True |
| agent_combined | 113390.95 | 4.60 | 66.20% | 23.84% | 29.99% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.