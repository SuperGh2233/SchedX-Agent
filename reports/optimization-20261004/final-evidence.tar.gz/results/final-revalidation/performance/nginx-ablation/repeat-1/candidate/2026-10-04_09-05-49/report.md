# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 67482.47 | 6.86 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 100496.45 | 5.09 | 48.92% | 25.80% | 50.10% | True |
| scx_only | 115538.00 | 2.07 | 71.21% | 69.83% | 30.71% | True |
| agent_combined | 113697.52 | 2.32 | 68.48% | 66.18% | 29.31% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.