from __future__ import annotations

import json
import hashlib
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/root/SchedX-Agent-optimization-20261003')
OUTPUT = ROOT / 'results/final-revalidation'
OUTPUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
from schedx.state import atomic_json
from scripts.run_optimization_benchmarks import source_digest

env = dict(os.environ)
env['PATH'] = str(ROOT / 'scx/output') + ':' + env['PATH']
stages = [
    ('unit-tests', [sys.executable, '-m', 'pytest', '-q']),
    ('compileall', [sys.executable, '-m', 'compileall', '-q', 'schedx', 'scripts']),
    ('performance', [sys.executable, 'scripts/run_optimization_benchmarks.py', '--baseline', '/root/SchedX-Agent-baseline-20261003', '--candidate', str(ROOT), '--candidate-bin', str(ROOT / 'scx/output'), '--repeats', '5', '--duration', '10', '--output', str(OUTPUT / 'performance')]),
    ('stability-30min', [sys.executable, 'scripts/verify_optimization.py', '--duration', '1800', '--output', str(OUTPUT / 'stability-30min')]),
    ('stability-2h', [sys.executable, 'scripts/verify_optimization.py', '--duration', '7200', '--fairness-only', '--output', str(OUTPUT / 'stability-2h')]),
]

def now():
    return datetime.now(timezone.utc).isoformat()

status = {'status': 'running', 'pid': os.getpid(), 'started_utc': now(), 'source_sha256': source_digest(ROOT), 'native_binary_sha256': hashlib.sha256((ROOT / 'scx/output/scx_agent').read_bytes()).hexdigest(), 'stages': []}
atomic_json(OUTPUT / 'pipeline.json', status)
try:
    for name, command in stages:
        row = {'name': name, 'started_utc': now(), 'status': 'running'}
        status['stages'].append(row)
        atomic_json(OUTPUT / 'pipeline.json', status)
        with (OUTPUT / (name + '.txt')).open('w') as log:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        row.update(status='passed' if result.returncode == 0 else 'failed', returncode=result.returncode, finished_utc=now())
        atomic_json(OUTPUT / 'pipeline.json', status)
        if result.returncode:
            raise RuntimeError(f'{name} failed; inspect {name}.txt and summary.json')
    perf = json.loads((OUTPUT / 'performance/summary.json').read_text())
    for case, metrics in perf['comparisons'].items():
        for metric, value in metrics.items():
            if len(value['samples']) != 5 or not value['all_samples_fairness_valid'] or value['stable_regression_over_5_percent']:
                raise RuntimeError(f'{case}/{metric} failed performance or fairness acceptance')
    for name in ('stability-30min', 'stability-2h'):
        result = json.loads((OUTPUT / name / 'summary.json').read_text())
        if result['status'] != 'passed' or result['final_sched_ext_state'] != 'disabled':
            raise RuntimeError(f'{name} failed acceptance or scheduler cleanup')
    if source_digest(ROOT) != status['source_sha256']:
        raise RuntimeError('Source changed during final revalidation')
    status['status'] = 'passed'
except Exception as exc:
    status.update(status='failed', error=str(exc))
finally:
    status['finished_utc'] = now()
    status['final_sched_ext_state'] = Path('/sys/kernel/sched_ext/state').read_text().strip()
    atomic_json(OUTPUT / 'pipeline.json', status)
print(json.dumps(status), flush=True)
sys.exit(0 if status['status'] == 'passed' else 1)
