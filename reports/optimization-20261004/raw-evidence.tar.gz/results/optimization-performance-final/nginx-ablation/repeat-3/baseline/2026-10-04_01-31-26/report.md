# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 72261.89 | 5.59 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 106733.52 | 5.05 | 47.70% | 9.66% | 51.12% | True |
| scx_only | 123812.84 | 5.61 | 71.34% | -0.36% | 32.71% | True |
| agent_combined | 119927.08 | 5.67 | 65.96% | -1.43% | 32.04% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.