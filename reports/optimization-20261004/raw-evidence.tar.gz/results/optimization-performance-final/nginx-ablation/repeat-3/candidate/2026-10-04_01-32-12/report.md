# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 74181.05 | 5.76 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 108094.44 | 5.01 | 45.72% | 13.02% | 51.65% | True |
| scx_only | 123334.12 | 5.40 | 66.26% | 6.25% | 32.92% | True |
| agent_combined | 119345.24 | 5.50 | 60.88% | 4.51% | 32.40% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.