# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 73648.98 | 5.79 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 106599.54 | 5.47 | 44.74% | 5.53% | 50.84% | True |
| scx_only | 123622.43 | 5.49 | 67.85% | 5.18% | 32.52% | True |
| agent_combined | 117827.34 | 5.29 | 59.98% | 8.64% | 34.04% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.