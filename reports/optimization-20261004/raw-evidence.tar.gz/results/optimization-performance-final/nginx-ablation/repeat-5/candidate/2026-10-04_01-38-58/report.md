# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 77030.96 | 5.78 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 107733.32 | 5.50 | 39.86% | 4.84% | 53.71% | True |
| scx_only | 123755.94 | 5.39 | 60.66% | 6.75% | 34.05% | True |
| agent_combined | 119285.65 | 5.51 | 54.85% | 4.67% | 34.43% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.