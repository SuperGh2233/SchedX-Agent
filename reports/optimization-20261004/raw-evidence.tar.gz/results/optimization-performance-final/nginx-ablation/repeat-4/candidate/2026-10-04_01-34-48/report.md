# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 67942.53 | 5.95 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 106965.46 | 5.11 | 57.44% | 14.12% | 47.73% | True |
| scx_only | 123385.94 | 5.46 | 81.60% | 8.24% | 30.05% | True |
| agent_combined | 119863.34 | 5.47 | 76.42% | 8.07% | 30.24% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.