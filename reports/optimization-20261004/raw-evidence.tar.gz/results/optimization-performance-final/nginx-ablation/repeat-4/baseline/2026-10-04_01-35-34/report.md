# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 72594.35 | 6.84 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 107313.87 | 5.03 | 47.83% | 26.46% | 50.68% | True |
| scx_only | 123218.88 | 5.20 | 69.74% | 23.98% | 32.74% | True |
| agent_combined | 117977.59 | 5.48 | 62.52% | 19.88% | 33.76% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.