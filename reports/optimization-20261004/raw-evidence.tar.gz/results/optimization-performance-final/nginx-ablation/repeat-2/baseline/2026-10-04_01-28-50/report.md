# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 61973.77 | 5.75 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 100499.23 | 4.86 | 62.16% | 15.48% | 46.44% | True |
| scx_only | 118130.30 | 4.48 | 90.61% | 22.09% | 29.00% | True |
| agent_combined | 118300.03 | 5.68 | 90.89% | 1.22% | 30.94% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.