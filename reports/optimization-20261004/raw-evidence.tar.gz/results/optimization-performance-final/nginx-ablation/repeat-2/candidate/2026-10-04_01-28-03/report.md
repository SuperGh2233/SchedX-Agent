# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 64776.80 | 5.75 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 96756.35 | 5.65 | 49.37% | 1.74% | 48.17% | True |
| scx_only | 110965.88 | 3.66 | 71.31% | 36.35% | 29.53% | True |
| agent_combined | 109149.78 | 3.86 | 68.50% | 32.87% | 28.13% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.