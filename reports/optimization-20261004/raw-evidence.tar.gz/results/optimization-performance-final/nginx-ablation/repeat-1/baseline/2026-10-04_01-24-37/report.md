# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 65294.15 | 6.83 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 98113.62 | 6.27 | 50.26% | 8.20% | 48.55% | True |
| scx_only | 110144.71 | 3.86 | 68.69% | 43.48% | 29.24% | True |
| agent_combined | 108467.34 | 3.73 | 66.12% | 45.39% | 28.80% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.