# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 60050.55 | 6.48 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 96782.49 | 4.81 | 61.17% | 25.77% | 46.89% | True |
| scx_only | 110360.59 | 3.38 | 83.78% | 47.84% | 28.77% | True |
| agent_combined | 108096.19 | 3.99 | 80.01% | 38.43% | 27.42% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.