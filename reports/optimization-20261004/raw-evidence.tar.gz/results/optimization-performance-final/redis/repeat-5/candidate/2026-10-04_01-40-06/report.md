# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83236.23 | n/a | 1.23 | n/a | n/a | True |
| interference | 60379.18 | n/a | 3.86 | n/a | 100.00% | True |
| schedx | 99760.57 | n/a | 2.17 | n/a | 45.11% | True |

## Result

- Interference QPS drop: 27.46%
- Agent QPS recovery: 65.22%
- Agent P99 reduction: 43.70%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.