# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83250.09 | n/a | 1.24 | n/a | n/a | True |
| interference | 66233.94 | n/a | 3.69 | n/a | 100.00% | True |
| schedx | 95075.11 | n/a | 2.30 | n/a | 53.99% | True |

## Result

- Interference QPS drop: 20.44%
- Agent QPS recovery: 43.54%
- Agent P99 reduction: 37.67%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.