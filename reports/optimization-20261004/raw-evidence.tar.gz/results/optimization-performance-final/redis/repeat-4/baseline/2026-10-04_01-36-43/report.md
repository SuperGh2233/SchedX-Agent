# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83277.81 | n/a | 1.26 | n/a | n/a | True |
| interference | 62243.25 | n/a | 3.66 | n/a | 100.00% | True |
| schedx | 99720.78 | n/a | 2.25 | n/a | 47.06% | True |

## Result

- Interference QPS drop: 25.26%
- Agent QPS recovery: 60.21%
- Agent P99 reduction: 38.66%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.