# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83291.69 | n/a | 1.24 | n/a | n/a | True |
| interference | 79643.20 | n/a | 3.25 | n/a | 100.00% | True |
| schedx | 99760.57 | n/a | 2.20 | n/a | 66.23% | True |

## Result

- Interference QPS drop: 4.38%
- Agent QPS recovery: 25.26%
- Agent P99 reduction: 32.28%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.