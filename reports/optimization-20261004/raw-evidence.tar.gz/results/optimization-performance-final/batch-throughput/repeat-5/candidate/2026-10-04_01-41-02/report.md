# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19553.03 | 0.32 | 95.49% | 0.00% |
| interference | 10001.95 | 3.25 | 0.00% | 100.00% |
| schedx | 16563.26 | 0.32 | 65.60% | 28.91% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True