# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19676.62 | 0.32 | 97.10% | 0.00% |
| interference | 9982.91 | 3.25 | 0.00% | 100.00% |
| schedx | 16347.61 | 0.32 | 63.76% | 31.28% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True