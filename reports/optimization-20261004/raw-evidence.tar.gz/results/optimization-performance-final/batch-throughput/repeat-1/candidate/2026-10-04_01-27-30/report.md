# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19742.03 | 0.32 | 95.50% | 0.00% |
| interference | 10098.04 | 3.25 | 0.00% | 100.00% |
| schedx | 16348.37 | 0.32 | 61.90% | 30.82% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True