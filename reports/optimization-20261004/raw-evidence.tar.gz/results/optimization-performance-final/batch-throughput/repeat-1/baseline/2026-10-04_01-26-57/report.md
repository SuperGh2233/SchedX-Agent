# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19771.19 | 0.32 | 96.76% | 0.00% |
| interference | 10048.15 | 3.25 | 0.00% | 100.00% |
| schedx | 16393.31 | 0.32 | 63.15% | 30.69% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True