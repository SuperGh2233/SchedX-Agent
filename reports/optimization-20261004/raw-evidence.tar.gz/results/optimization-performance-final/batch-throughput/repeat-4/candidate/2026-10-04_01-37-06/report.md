# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19631.52 | 0.32 | 96.48% | 0.00% |
| interference | 9991.49 | 3.25 | 0.00% | 100.00% |
| schedx | 15878.61 | 0.32 | 58.92% | 33.84% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True