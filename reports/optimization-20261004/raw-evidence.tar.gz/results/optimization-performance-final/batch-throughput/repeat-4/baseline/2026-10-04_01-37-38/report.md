# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19674.43 | 0.32 | 97.43% | 0.00% |
| interference | 9965.45 | 3.25 | 0.00% | 100.00% |
| schedx | 16541.71 | 0.32 | 65.99% | 29.48% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True