# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19808.65 | 0.32 | 98.13% | 0.00% |
| interference | 9997.77 | 3.25 | 0.00% | 100.00% |
| schedx | 16314.97 | 0.32 | 63.19% | 31.35% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True