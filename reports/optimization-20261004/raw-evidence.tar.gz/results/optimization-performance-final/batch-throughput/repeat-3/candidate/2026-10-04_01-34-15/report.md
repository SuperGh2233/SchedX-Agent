# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19714.98 | 0.32 | 96.08% | 0.00% |
| interference | 10054.68 | 3.25 | 0.00% | 100.00% |
| schedx | 16418.76 | 0.32 | 63.29% | 30.14% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True