# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19771.27 | 0.32 | 96.01% | 0.00% |
| interference | 10087.02 | 3.19 | 0.00% | 100.00% |
| schedx | 16316.00 | 0.32 | 61.75% | 31.45% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True