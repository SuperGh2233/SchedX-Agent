# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19818.67 | 0.32 | 97.26% | 0.00% |
| interference | 10047.20 | 3.25 | 0.00% | 100.00% |
| schedx | 16210.68 | 0.32 | 61.35% | 33.03% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True