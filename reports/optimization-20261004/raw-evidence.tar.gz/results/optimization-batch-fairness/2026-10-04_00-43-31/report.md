# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19758.83 | 0.32 | 95.71% | 0.00% |
| interference | 10095.96 | 3.25 | 0.00% | 100.00% |
| schedx | 17157.15 | 0.32 | 69.94% | 23.02% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False