# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 63647.90 | 6.10 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 99757.29 | 4.74 | 56.73% | 22.30% | 48.76% | True |
| scx_only | 112324.51 | 3.83 | 76.48% | 37.21% | 29.29% | True |
| agent_combined | 110841.54 | 4.70 | 74.15% | 22.95% | 28.63% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.