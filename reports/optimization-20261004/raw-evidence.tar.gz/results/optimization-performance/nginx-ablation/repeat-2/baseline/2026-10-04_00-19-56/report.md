# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 63644.39 | 5.97 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 98525.14 | 5.07 | 54.81% | 15.08% | 48.17% | True |
| scx_only | 114968.87 | 4.58 | 80.64% | 23.28% | 29.38% | True |
| agent_combined | 113633.67 | 4.96 | 78.54% | 16.92% | 28.42% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.