# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 60565.73 | 6.00 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 95456.25 | 5.22 | 57.61% | 13.00% | 46.04% | True |
| scx_only | 111343.59 | 3.45 | 83.84% | 42.50% | 28.18% | True |
| agent_combined | 110775.75 | 3.99 | 82.90% | 33.50% | 27.07% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.