# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 69827.06 | 5.31 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 96820.82 | 4.59 | 38.66% | 13.56% | 52.13% | True |
| scx_only | 112662.96 | 3.51 | 61.35% | 33.90% | 31.67% | True |
| agent_combined | 111610.45 | 4.35 | 59.84% | 18.08% | 30.95% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.