# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 64828.66 | 5.88 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 96554.29 | 5.08 | 48.94% | 13.61% | 48.93% | True |
| scx_only | 109908.23 | 3.38 | 69.54% | 42.52% | 29.92% | True |
| agent_combined | 108580.56 | 4.45 | 67.49% | 24.32% | 28.85% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.