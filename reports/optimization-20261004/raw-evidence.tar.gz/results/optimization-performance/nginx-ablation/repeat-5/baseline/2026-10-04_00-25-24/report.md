# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 57162.70 | 7.56 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 99837.64 | 4.90 | 74.66% | 35.19% | 43.66% | True |
| scx_only | 111448.37 | 3.97 | 94.97% | 47.49% | 27.38% | True |
| agent_combined | 110090.46 | 4.05 | 92.59% | 46.43% | 25.98% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.