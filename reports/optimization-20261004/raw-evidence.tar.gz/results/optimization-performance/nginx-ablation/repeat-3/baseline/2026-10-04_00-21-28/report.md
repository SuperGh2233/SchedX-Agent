# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 59605.90 | 5.89 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 99922.66 | 5.47 | 67.64% | 7.13% | 46.37% | True |
| scx_only | 113929.38 | 4.19 | 91.14% | 28.86% | 27.31% | True |
| agent_combined | 112856.16 | 4.63 | 89.34% | 21.39% | 26.68% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.