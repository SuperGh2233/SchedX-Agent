# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 63638.62 | 6.07 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 97120.86 | 5.12 | 52.61% | 15.65% | 50.10% | True |
| scx_only | 111691.60 | 3.78 | 75.51% | 37.73% | 30.06% | True |
| agent_combined | 110893.48 | 4.06 | 74.25% | 33.11% | 28.88% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.