# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 58856.45 | 7.92 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 95356.81 | 4.64 | 62.02% | 41.41% | 46.48% | True |
| scx_only | 114010.06 | 4.22 | 93.71% | 46.72% | 28.48% | True |
| agent_combined | 110225.89 | 4.05 | 87.28% | 48.86% | 27.18% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.