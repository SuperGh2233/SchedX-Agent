# SchedX-Agent Nginx Ablation Report

| Phase | Mean RPS | Mean P99 (ms) | RPS gain | P99 reduction | Background retention | Valid |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| default | 59017.37 | 5.47 | 0.00% | 0.00% | 100.00% | True |
| cgroup_only | 100425.90 | 5.47 | 70.16% | 0.00% | 44.85% | True |
| scx_only | 112471.26 | 3.84 | 90.57% | 29.80% | 27.48% | True |
| agent_combined | 109609.11 | 4.46 | 85.72% | 18.46% | 26.68% | True |

The four phases isolate the contribution of cgroup v2, native sched_ext, and the combined Agent.
Performance claims are valid only when the configured background-progress floor is met.