# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83194.67 | n/a | 1.23 | n/a | n/a | True |
| interference | 55273.05 | n/a | 4.28 | n/a | 100.00% | True |
| schedx | 99720.78 | n/a | 2.19 | n/a | 39.51% | True |

## Result

- Interference QPS drop: 33.56%
- Agent QPS recovery: 80.41%
- Agent P99 reduction: 48.80%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.