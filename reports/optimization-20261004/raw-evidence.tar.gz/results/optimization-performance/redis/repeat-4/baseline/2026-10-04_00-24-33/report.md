# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83277.81 | n/a | 1.25 | n/a | n/a | True |
| interference | 55297.50 | n/a | 3.82 | n/a | 100.00% | True |
| schedx | 90678.27 | n/a | 2.33 | n/a | 42.75% | True |

## Result

- Interference QPS drop: 33.60%
- Agent QPS recovery: 63.98%
- Agent P99 reduction: 38.92%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.