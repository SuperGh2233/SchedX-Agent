# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83222.38 | n/a | 1.22 | n/a | n/a | True |
| interference | 70982.40 | n/a | 3.19 | n/a | 100.00% | True |
| schedx | 99760.57 | n/a | 2.29 | n/a | 55.80% | True |

## Result

- Interference QPS drop: 14.71%
- Agent QPS recovery: 40.54%
- Agent P99 reduction: 28.08%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.