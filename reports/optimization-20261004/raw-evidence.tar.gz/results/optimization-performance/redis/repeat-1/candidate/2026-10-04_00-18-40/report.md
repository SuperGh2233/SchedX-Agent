# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83250.09 | n/a | 1.22 | n/a | n/a | True |
| interference | 82863.77 | n/a | 3.25 | n/a | 100.00% | True |
| schedx | 99641.29 | n/a | 2.21 | n/a | 72.84% | False |

## Result

- Interference QPS drop: 0.46%
- Agent QPS recovery: 20.25%
- Agent P99 reduction: 32.20%
- Fairness floor: 25.00%
- Result valid for claims: False

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.