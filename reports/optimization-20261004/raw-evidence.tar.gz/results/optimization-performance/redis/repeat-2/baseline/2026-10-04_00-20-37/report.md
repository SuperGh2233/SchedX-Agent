# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83250.09 | n/a | 1.25 | n/a | n/a | True |
| interference | 52290.31 | n/a | 3.93 | n/a | 100.00% | True |
| schedx | 99840.26 | n/a | 2.16 | n/a | 37.97% | True |

## Result

- Interference QPS drop: 37.19%
- Agent QPS recovery: 90.93%
- Agent P99 reduction: 45.02%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.