# SchedX-Agent Redis Mixed Workload Report

This fixed-work benchmark rotates phase order across repeats to reduce order bias.
Each row reports a small-sample Student-t 95% confidence interval.

| Phase | Mean QPS | 95% CI | Mean P99 (ms) | 95% CI | Background retention | Valid |
| --- | ---: | --- | ---: | --- | ---: | --- |
| baseline | 83222.38 | n/a | 1.24 | n/a | n/a | True |
| interference | 58506.91 | n/a | 3.89 | n/a | 100.00% | True |
| schedx | 99720.78 | n/a | 2.21 | n/a | 44.35% | True |

## Result

- Interference QPS drop: 29.70%
- Agent QPS recovery: 70.44%
- Agent P99 reduction: 43.02%
- Fairness floor: 25.00%
- Result valid for claims: True

## Agent Evidence

The SchedX phase invokes the existing latency-first AgentLoop for Redis;
the saved action evidence includes classification, scx/cgroup execution, eBPF evidence, and cleanup.