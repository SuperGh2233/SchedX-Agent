# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19709.32 | 0.32 | 98.62% | 0.00% |
| interference | 9923.10 | 3.25 | 0.00% | 100.00% |
| schedx | 6596.85 | 0.32 | -33.52% | 178.82% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False