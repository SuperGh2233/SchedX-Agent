# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19756.42 | 0.32 | 98.05% | 0.00% |
| interference | 9975.68 | 3.25 | 0.00% | 100.00% |
| schedx | 15365.07 | 0.32 | 54.03% | 37.50% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True