# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19707.41 | 0.32 | 98.57% | 0.00% |
| interference | 9924.69 | 3.25 | 0.00% | 100.00% |
| schedx | 14969.59 | 0.32 | 50.83% | 38.94% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True