# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19775.12 | 0.32 | 98.35% | 0.00% |
| interference | 9969.72 | 3.25 | 0.00% | 100.00% |
| schedx | 6787.01 | 0.32 | -31.92% | 172.78% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False