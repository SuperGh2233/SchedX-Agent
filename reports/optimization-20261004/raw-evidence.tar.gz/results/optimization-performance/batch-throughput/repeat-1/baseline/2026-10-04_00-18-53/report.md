# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 20151.76 | 0.32 | 99.70% | 0.00% |
| interference | 10091.07 | 3.19 | 0.00% | 100.00% |
| schedx | 15257.12 | 0.32 | 51.19% | 39.08% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True