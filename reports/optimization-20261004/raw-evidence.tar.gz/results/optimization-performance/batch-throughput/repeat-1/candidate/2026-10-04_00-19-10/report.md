# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19877.38 | 0.32 | 100.06% | 0.00% |
| interference | 9935.74 | 3.25 | 0.00% | 100.00% |
| schedx | 6824.64 | 0.30 | -31.31% | 168.26% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False