# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19850.07 | 0.32 | 96.63% | 0.00% |
| interference | 10095.03 | 3.19 | 0.00% | 100.00% |
| schedx | 15135.58 | 0.32 | 49.93% | 39.44% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True