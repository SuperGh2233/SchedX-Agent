# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19765.95 | 0.32 | 96.93% | 0.00% |
| interference | 10037.23 | 3.25 | 0.00% | 100.00% |
| schedx | 6752.71 | 0.32 | -32.72% | 171.63% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False