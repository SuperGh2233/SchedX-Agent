# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19720.31 | 0.32 | 96.44% | 0.00% |
| interference | 10038.74 | 3.25 | 0.00% | 100.00% |
| schedx | 15030.51 | 0.32 | 49.73% | 40.53% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True