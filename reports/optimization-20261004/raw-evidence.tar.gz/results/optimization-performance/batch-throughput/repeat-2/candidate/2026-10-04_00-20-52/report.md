# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19716.59 | 0.32 | 100.81% | 0.00% |
| interference | 9818.51 | 3.25 | 0.00% | 100.00% |
| schedx | 6579.18 | 0.27 | -32.99% | 167.88% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False