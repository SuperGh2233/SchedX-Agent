# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 20004.19 | 0.31 | 98.77% | 0.00% |
| interference | 10064.22 | 3.25 | 0.00% | 100.00% |
| schedx | 16426.10 | 0.32 | 63.21% | 31.93% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: True