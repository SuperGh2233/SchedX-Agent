# SchedX-Agent Batch Throughput Report

| Phase | Events/s | P95 latency (ms) | Change vs interference | Background progress |
| --- | ---: | ---: | ---: | ---: |
| baseline | 19939.12 | 0.32 | 99.01% | 0.00% |
| interference | 10019.23 | 3.25 | 0.00% | 100.00% |
| schedx | 17449.06 | 0.32 | 74.16% | 21.25% |

The SchedX phase launches sysbench first, identifies the live batch workload,
and applies the throughput expert while CPU interference is active.

- Interference detected: True
- Result valid for claims: False